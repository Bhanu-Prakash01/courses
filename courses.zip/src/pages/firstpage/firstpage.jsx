import './firstpage.css'
import Courses from '../../components/courses/courses';
import Navbar from '../../components/navbar/navbar';
import Faq from '../../components/faq/faq';
import Reviews from '../../components/reviews/reviews';
function Firstpage(){
    return(
        <>
        <nav><Navbar/></nav>
        <div className="courses">
            <h1 style={{color:'white',marginTop:-100}}>Courses</h1>
            <div className="cour">
                <Courses/>
                <Courses/>
                <Courses/>
            </div>
        </div>
        <div className="review">
        <h1 style={{color:'white',marginTop:100}}>Reviews</h1>
            <div className="rev">
                <Reviews/>
                <Reviews/>
                <Reviews/>
                <Reviews/>
                <Reviews/>
                <Reviews/>
            </div>
        </div>
        <div className="faq">
        <h1 style={{color:'white',marginTop:10}}>FAQ</h1>
            <div className="f">
                <Faq/>
                <Faq/>
                <Faq/>
                <Faq/>
                <Faq/>
                <Faq/>
            </div>
        </div>
        </>
    )
}
export default Firstpage;
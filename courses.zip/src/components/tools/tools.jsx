import './tools.css';
function Tools(){
    return(
        <>
            <div className="tool-box">
                <div className="slider">
                    <img src="https://www.xebiaacademyglobal.com/careerpro_style/assets/images/Tools_Language/node.svg" alt="nodejs" className="silderimage" />
                    <img src="https://www.xebiaacademyglobal.com/careerpro_style/assets/images/Tools_Language/react.svg" alt="react" className="silderimage" />
                    <img src="https://www.xebiaacademyglobal.com/careerpro_style/assets/images/Tools_Language/mongo.svg" alt="mongodb" className="silderimage" />
                    <img src="https://www.xebiaacademyglobal.com/careerpro_style/assets/images/Tools_Language/html.svg" alt="html" className="silderimage" />
                </div>
            </div>
        </>
    )
}
export default Tools;

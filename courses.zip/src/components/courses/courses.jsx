import './courses.css';
import {useHistory} from 'react-router-dom';
function Courses(){
    let history = useHistory();
    return(
        <>
        <div className="courses-box" onClick={()=>history.push('/1')}>
            <div className="courses-top">
                <img src="https://d27028dliefpk3.cloudfront.net/static/welcome/web-dev.svg" alt="" className="courses-img" />
                <div className="right">
                    <label className="courses-mainheading">FULL STACK</label>
                    <h2 className="coursename">Web Development</h2>
                    <div className="courses-btn">
                        <label className="coursestimeline">Full-Time</label>
                        <label className="coursestimetaken">30 weeks</label>
                    </div>
                </div>
            </div>
            <div className="bottom">
                <label className="coursestart">Starts:</label>
                <div className="verybottom">
                    <span className="coursedate">21 June 2021 </span>
                    <i class="fab fa-500px"></i>
                </div>
            </div>
        </div>
        
        </>
    )
}
export default Courses;
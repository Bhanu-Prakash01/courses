import './navbar.css'
function Navbar(){
    return(
        <>
        <div className="nav-box">
            <span className="nav-logo">LOGO</span>
            <ul className="nav-ul">
                <li className="nav-li">COURSES</li>
                <li className="nav-li">FAQ</li>
                <li className="nav-li">CONTACT US</li>
            </ul>
        </div>
        </>
    )
}
export default Navbar;
import './programoverview.css';
import Programovercard from './programovercard';
function Programoverview(){
    return(
        <>
        <div className="programoverview-box">
            <div className="programoverviewtop">
                <p className="programover-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos corporis dolorem rem odit optio maxime maiores, eveniet officiis tempore reiciendis blanditiis rerum provident nostrum aliquid placeat quibusdam, voluptate necessitatibus ducimus quidem expedita, unde ipsam consequuntur magni. Reprehenderit voluptate sunt vero a est dolor magnam! Fugit, natus! Minima unde illum expedita.</p>
            </div>
            <div className="programoverview-bottom">
                <Programovercard/>
                <Programovercard/>
                <Programovercard/>
                <Programovercard/>
                <Programovercard/>
                <Programovercard/>
                <Programovercard/>
                <Programovercard/>
                <Programovercard/>
                <Programovercard/>
                <Programovercard/>
                <Programovercard/>
            </div>
        </div>
        </>
    )
}
export default Programoverview;
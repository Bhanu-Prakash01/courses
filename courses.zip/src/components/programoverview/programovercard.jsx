function Programovercard(){
    return(
        <>
        <div className="programoverviewminibox">
            <span className="minibox-logo"><i class="fas fa-percent"></i></span>
            <p className="minibox-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore, optio.</p>
        </div>
        </>
    )
}
export default Programovercard;
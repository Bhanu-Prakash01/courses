import './reviews.css'
function Reviews(){
    return(
        <>
        <div className="review-box">
            <div className="review-identity">
                <p className="reviewername">Sunny</p>
                <span className="review-rating">++++</span>
            </div>
            <div className="review-text-box"><p className="review-text">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore corporis omnis facere ut magnam saepe architecto minus in tempora ratione, ipsum pariatur, nesciunt non ullam adipisci voluptas rem tempore rerum!</p></div>
        </div>
        </>
    )
}
export default Reviews;